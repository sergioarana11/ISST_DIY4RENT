package es.upm.isst.grupo07.diy4rent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Diy4rentApplication {

	public static void main(String[] args) {
		SpringApplication.run(Diy4rentApplication.class, args);
	}

}
