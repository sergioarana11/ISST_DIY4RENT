package es.upm.isst.grupo07.diy4rent;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Diy4rentApplicationTests {

	@Test
	void contextLoads() {
	}

}
